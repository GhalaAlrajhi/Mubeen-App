import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 's_t_tor_t_t_s_page_widget.dart' show STTorTTSPageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class STTorTTSPageModel extends FlutterFlowModel<STTorTTSPageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
