package com.mycompany.mubeen

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
